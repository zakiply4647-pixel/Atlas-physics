/* ATLAS PHYSICS application — no external JavaScript libraries required */
"use strict";

const DB={
 units:{electric:"الظواهر الكهربائية",mechanics:"الظواهر الميكانيكية",light:"الظواهر الضوئية",matter:"المادة وتحولاتها"}
,
 lessons:[
 {id:"current",unit:"electric",title:"التوتر الكهربائي وشدة التيار",summary:"الكميات الكهربائية وأجهزة القياس ووحداتها.",time:"12 دقيقة",level:"أساسي",objectives:["تمييز التوتر عن شدة التيار","معرفة وحدات القياس","اختيار جهاز القياس المناسب"],sections:[["شدة التيار","شدة التيار كمية فيزيائية تعبّر عن معدل مرور الشحنات في ناقل. يرمز لها I وتقاس بالأمبير A."],["التوتر الكهربائي","التوتر بين نقطتين يرمز له U ويقاس بالفولط V. يقيس الفولطمتر التوتر بين طرفي عنصر."],["أجهزة القياس","يوصل الأمبيرمتر على التسلسل، ويوصل الفولطمتر على التفرع بين طرفي العنصر. اختر مجال القياس المناسب واحترم القطبية."]],formula:"I → A   |   U → V",example:"إذا أشار الأمبيرمتر إلى 0.4 A فإن شدة التيار هي 0.4 أمبير.",summaryEnd:"لكل كمية رمز ووحدة وجهاز قياس مناسب."}
,
 {id:"ohm",unit:"electric",title:"قانون أوم والمقاومة",summary:"العلاقة بين التوتر وشدة التيار والمقاومة.",time:"15 دقيقة",level:"أساسي",objectives:["فهم المقاومة","استعمال قانون أوم","حل مسألة بوحداتها"],sections:[["المقاومة الكهربائية","المقاومة خاصية للناقل تعبّر عن ممانعته لمرور التيار. يرمز لها R وتقاس بالأوم Ω."],["قانون أوم","في ناقل أومي وتحت شروط ثابتة يتناسب التوتر U طرديًا مع شدة التيار I، وثابت التناسب هو R."],["منهجية الحل","اكتب المعطيات والمطلوب، اختر العلاقة، عوّض مع الوحدات ثم اكتب النتيجة النهائية."]],formula:"U = R × I   |   I = U / R",example:"R = 5 Ω وU = 10 V، إذن I = 10 / 5 = 2 A.",summaryEnd:"تأكد من توافق الوحدات قبل التعويض."}
,
 {id:"power",unit:"electric",title:"الاستطاعة الكهربائية",summary:"تعريف الاستطاعة وعلاقتها بالتوتر والتيار.",time:"13 دقيقة",level:"متوسط",objectives:["تعريف الاستطاعة","تطبيق العلاقة","معرفة الواط"],sections:[["المفهوم","الاستطاعة تعبّر عن معدل تحويل الطاقة في وحدة الزمن، ويرمز لها P وتقاس بالواط W."],["العلاقة","في دارة تيار مستمر، يمكن حساب الاستطاعة بالعلاقة P = U × I."],["تطبيق","تساعد بيانات الاستطاعة على مقارنة معدل تحويل الطاقة للأجهزة أثناء التشغيل."]],formula:"P = U × I",example:"U = 12 V وI = 2 A، إذن P = 24 W.",summaryEnd:"الفولط مضروبًا في الأمبير يعطي الواط."}
,
 {id:"energy",unit:"electric",title:"الطاقة الكهربائية",summary:"الاستطاعة ومدة التشغيل والطاقة المستهلكة.",time:"14 دقيقة",level:"متوسط",objectives:["فهم الطاقة","استعمال E=P×t","تمييز وحدات الطاقة"],sections:[["الطاقة والزمن","تزداد الطاقة المحولة بزيادة الاستطاعة أو مدة التشغيل."],["وحدات الطاقة","إذا كانت P بالواط وt بالثانية تكون E بالجول. وإذا كانت t بالساعة تكون E بالواط ساعي."],["التحويل","1 kWh يساوي 1000 Wh. انتبه إلى توافق الوحدات قبل الحساب."]],formula:"E = P × t",example:"P = 60 W وt = 30 s، إذن E = 1800 J.",summaryEnd:"الوحدة النهائية تتحدد بوحدات الاستطاعة والزمن."}
,
 {id:"forces",unit:"mechanics",title:"الأفعال الميكانيكية والقوى",summary:"تأثير الأجسام وتمثيل القوة بسهم.",time:"16 دقيقة",level:"متوسط",objectives:["تمييز الأفعال التلامسية والبعدية","تحديد خصائص القوة","معرفة وحدة القوة"],sections:[["الفعل الميكانيكي","قد يغير تأثير جسم في جسم آخر حركته أو يشوهه. وقد يكون الفعل تلامسيًا أو عن بعد."],["تمثيل القوة","نمثل القوة بسهم يوضح نقطة التأثير والاتجاه والمنحى والشدة."],["وحدة القوة","تقاس القوة بالنيوتن N ويمكن قياسها بالدينامومتر."]],formula:"القوة F · الوحدة N",example:"إذا كان السلم 1 cm لكل 2 N، فإن قوة 6 N تمثل بسهم طوله 3 cm.",summaryEnd:"احترم خصائص القوة وسلّم الرسم."}
,
 {id:"weight",unit:"mechanics",title:"الكتلة والوزن",summary:"الفرق بين الكتلة وقوة جذب الأرض.",time:"14 دقيقة",level:"متوسط",objectives:["تمييز الكتلة عن الوزن","معرفة kg وN","حساب الوزن"],sections:[["الكتلة","الكتلة مقدار المادة في الجسم، يرمز لها m وتقاس بالكيلوغرام kg."],["الوزن","الوزن قوة جذب الأرض للجسم، يرمز له P ويقاس بالنيوتن N."],["العلاقة","قرب سطح الأرض نستعمل P = m × g حيث g شدة مجال الثقالة."]],formula:"P = m × g",example:"m = 3 kg وg ≈ 10 N/kg، إذن P ≈ 30 N.",summaryEnd:"الكتلة بالكيلوغرام والوزن بالنيوتن."}
,
 {id:"light",unit:"light",title:"انتشار الضوء",summary:"المصادر الضوئية والشعاع والانتشار المستقيم.",time:"13 دقيقة",level:"أساسي",objectives:["تمييز المصادر","تمثيل الشعاع","شرح تشكل الظل"],sections:[["مصادر الضوء","المصدر الأولي يصدر الضوء بنفسه، والجسم المضاءة أسطحه قد يعكس الضوء الساقط عليه."],["الشعاع الضوئي","يمثل بخط مستقيم وسهم يوضح منحى الانتشار."],["الانتشار المستقيم","في وسط شفاف متجانس ينتشر الضوء في خطوط مستقيمة، ويمكن تفسير الظل بحجب الأشعة."]],formula:"مصدر ضوئي → جسم / عين",example:"يحجب الجسم المعتم الضوء عن منطقة من الشاشة فتظهر منطقة ظل.",summaryEnd:"ارسم السهم في منحى انتشار الضوء."}
,
 {id:"matter",unit:"matter",title:"المادة وتحولاتها",summary:"التمييز بين التحول الفيزيائي والكيميائي.",time:"15 دقيقة",level:"متوسط",objectives:["وصف التحول","التمييز بين النوعين","صياغة استنتاج"],sections:[["التحول الفيزيائي","تتغير الحالة أو الهيئة دون تكوّن مادة جديدة، مثل انصهار الجليد."],["التحول الكيميائي","تتكون مواد جديدة، وقد تظهر مؤشرات مثل الغاز أو تغير اللون بحسب التجربة."],["منهجية الاستنتاج","سجّل الملاحظة أولًا ثم اكتب الاستنتاج الذي تدعمه الأدلة."]],formula:"متفاعلات → نواتج",example:"انصهار الجليد تحول فيزيائي لأن المادة تبقى ماءً.",summaryEnd:"تغير الحالة لا يعني بالضرورة تكوّن مادة جديدة."}

 ],
 exercises:[
 {id:1,unit:"electric",level:"easy",title:"حساب شدة التيار",prompt:"مقاومة R=4 Ω موصولة بتوتر U=8 V. احسب I.",tip:"استخدم I=U/R.",steps:["المعطيات: U=8 V وR=4 Ω.","العلاقة: I=U/R.","التعويض: I=8/4=2 A."],answer:"I = 2 A"}
,
 {id:2,unit:"electric",level:"easy",title:"حساب المقاومة",prompt:"يمر تيار 0.5 A تحت توتر 6 V. احسب R.",tip:"المقاومة هي التوتر مقسومًا على التيار.",steps:["U=6 V وI=0.5 A.","R=U/I.","R=6/0.5=12 Ω."],answer:"R = 12 Ω"}
,
 {id:3,unit:"electric",level:"medium",title:"حساب الاستطاعة",prompt:"جهاز يعمل تحت 12 V ويمر فيه تيار 2 A. احسب P.",tip:"الاستطاعة حاصل ضرب U في I.",steps:["U=12 V وI=2 A.","P=U×I.","P=12×2=24 W."],answer:"P = 24 W"}
,
 {id:4,unit:"electric",level:"medium",title:"الطاقة والزمن",prompt:"مصباح استطاعته 60 W اشتغل 30 ثانية. احسب الطاقة.",tip:"استخدم E=P×t.",steps:["P=60 W وt=30 s.","E=P×t.","E=60×30=1800 J."],answer:"E = 1800 J"}
,
 {id:5,unit:"mechanics",level:"easy",title:"حساب الوزن",prompt:"كتلة جسم 2 kg وg=10 N/kg. احسب الوزن.",tip:"اضرب الكتلة في شدة مجال الثقالة.",steps:["m=2 kg وg=10 N/kg.","P=m×g.","P=2×10=20 N."],answer:"P = 20 N"}
,
 {id:6,unit:"light",level:"hard",title:"تحليل الظل",prompt:"وضع جسم معتم بين مصدر ضوئي وشاشة. فسّر ظهور منطقة مظلمة.",tip:"فكر في مسار الضوء المستقيم.",steps:["الجسم المعتم يحجب جزءًا من الضوء.","لا تصل الأشعة المحجوبة إلى المنطقة المقابلة.","تتكون منطقة ظل على الشاشة."],answer:"يحجب الجسم الضوء عن جزء من الشاشة."}

 ],
 questions:[
 {cat:"الكهرباء",q:"ما وحدة قياس شدة التيار؟",opts:["الفولط","الأمبير","الأوم","الواط"],a:1,why:"تقاس شدة التيار بالأمبير A."}
,
 {cat:"الكهرباء",q:"R=4 Ω وU=8 V. ما شدة التيار؟",opts:["0.5 A","2 A","4 A","32 A"],a:1,why:"I=U/R=8/4=2 A."}
,
 {cat:"الكهرباء",q:"كيف يوصل الفولطمتر؟",opts:["على التسلسل","على التفرع","مكان المولد","دون دارة"],a:1,why:"يوصل الفولطمتر على التفرع بين طرفي العنصر."}
,
 {cat:"الكهرباء",q:"ما وحدة المقاومة؟",opts:["الأمبير","النيوتن","الأوم","الكيلوغرام"],a:2,why:"وحدة المقاومة هي الأوم Ω."}
,
 {cat:"الكهرباء",q:"U=12 V وI=2 A. ما الاستطاعة؟",opts:["6 W","10 W","14 W","24 W"],a:3,why:"P=U×I=24 W."}
,
 {cat:"الميكانيك",q:"ما وحدة القوة؟",opts:["الكيلوغرام","النيوتن","الفولط","الواط"],a:1,why:"تقاس القوة بالنيوتن N."}
,
 {cat:"الميكانيك",q:"ما وحدة الكتلة؟",opts:["النيوتن","الجول","الكيلوغرام","الأمبير"],a:2,why:"وحدة الكتلة هي الكيلوغرام kg."}
,
 {cat:"الميكانيك",q:"m=3 kg وg=10 N/kg. الوزن؟",opts:["3 N","13 N","30 N","0.3 N"],a:2,why:"P=m×g=30 N."}
,
 {cat:"الضوء",q:"كيف نمثل الشعاع الضوئي؟",opts:["دائرة","خط وسهم","مربع","منحنى"],a:1,why:"يمثل الشعاع بخط وسهم يوضح منحى الانتشار."}
,
 {cat:"المادة",q:"انصهار الجليد مثال على:",opts:["تحول فيزيائي","احتراق","تكوّن مادة جديدة","تحول كيميائي دائمًا"],a:0,why:"يتغير طور الماء دون تكوّن مادة جديدة."}

 ],
 formulas:[
 {title:"قانون أوم",eq:"U = R × I",meaning:"التوتر يساوي المقاومة مضروبة في شدة التيار.",units:"U: V · R: Ω · I: A",cat:"الكهرباء"}
,
 {title:"شدة التيار",eq:"I = U / R",meaning:"حساب شدة التيار بقسمة التوتر على المقاومة.",units:"I: A · U: V · R: Ω",cat:"الكهرباء"}
,
 {title:"المقاومة",eq:"R = U / I",meaning:"حساب المقاومة بقسمة التوتر على التيار.",units:"R: Ω · U: V · I: A",cat:"الكهرباء"}
,
 {title:"الاستطاعة",eq:"P = U × I",meaning:"استطاعة جهاز كهربائي في دارة تيار مستمر.",units:"P: W · U: V · I: A",cat:"الكهرباء"}
,
 {title:"الطاقة",eq:"E = P × t",meaning:"الطاقة المحولة تساوي الاستطاعة في زمن التشغيل.",units:"E: J · P: W · t: s",cat:"الكهرباء"}
,
 {title:"الوزن",eq:"P = m × g",meaning:"الوزن يساوي الكتلة مضروبة في مجال الثقالة.",units:"P: N · m: kg · g: N/kg",cat:"الميكانيك"}
,
 {title:"الكتلة",eq:"m = P / g",meaning:"حساب الكتلة من الوزن وشدة مجال الثقالة.",units:"m: kg · P: N · g: N/kg",cat:"الميكانيك"}
,
 {title:"تحويل الطاقة",eq:"1 kWh = 1000 Wh",meaning:"الكيلوواط ساعي يساوي ألف واط ساعي.",units:"وحدة طاقة",cat:"الكهرباء"}

 ]
}
;

const KEY="atlas-physics-pro-state";

const fresh=()=>({done:[],xp:0,answers:0,correct:0,theme:"dark"});

let state=loadState(),labMode="ohm",quiz={i:0,order:[],score:0,answered:false,finished:false}
;

function loadState(){try{return Object.assign(fresh(),JSON.parse(localStorage.getItem(KEY))||{})}
catch(e){return fresh()}
}

function save(){try{localStorage.setItem(KEY,JSON.stringify(state))}
catch(e){toast("تعذّر حفظ التقدم في هذا المتصفح.","error")}
updateStats();
renderProgress()}

function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(text,type="success"){const n=document.createElement("div");n.className="toast "+type;n.textContent=text;document.getElementById("toastRegion").appendChild(n);setTimeout(()=>n.remove(),3000)}
function go(id){const p=document.getElementById(id);if(!p)return;document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x===p));document.querySelectorAll("[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===id));document.getElementById("nav").classList.remove("open");history.replaceState(null,"","#"+id);window.scrollTo({top:0,behavior:"smooth"});if(id==="lessons")renderLessons();if(id==="practice")renderExercises();if(id==="formulas")renderFormulas();if(id==="progress")renderProgress()}
document.addEventListener("click",e=>{let b=e.target.closest("[data-page]");if(b)go(b.dataset.page);let g=e.target.closest("[data-go]");if(g)go(g.dataset.go)});
document.getElementById("menu").onclick=()=>document.getElementById("nav").classList.toggle("open");
document.getElementById("theme").onclick=toggleTheme;
function toggleTheme(){state.theme=state.theme==="light"?"dark":"light";document.body.classList.toggle("light",state.theme==="light");document.getElementById("theme").textContent=state.theme==="light"?"☾":"☼";save()}
function updateStats(){let done=DB.lessons.filter(x=>state.done.includes(x.id)).length,pct=state.answers?Math.round(state.correct/state.answers*100):0;document.getElementById("doneCount").textContent=done;document.getElementById("xpCount").textContent=state.xp+" XP";document.getElementById("accuracy").textContent=pct+"%";document.getElementById("homeBar").style.width=(done/DB.lessons.length*100)+"%";document.getElementById("resume").textContent=done?`أكملت ${done} من ${DB.lessons.length} دروس. واصل التعلّم!`:"ابدأ أول درس لك واكتشف كيف تتقدم خطوة بخطوة."}
function renderLessons(){let q=document.getElementById("searchLesson").value.toLowerCase().trim(),u=document.getElementById("unitFilter").value;let arr=DB.lessons.filter(x=>(u==="all"||x.unit===u)&&(!q||(x.title+x.summary+DB.units[x.unit]).toLowerCase().includes(q)));document.getElementById("lessonGrid").innerHTML=arr.length?arr.map((x,i)=>`<article class="card lesson-card"><span class="tag">${DB.units[x.unit]}</span><h3>${String(i+1).padStart(2,"0")} · ${esc(x.title)}</h3><p>${esc(x.summary)}</p><small>${x.time} · ${x.level} ${state.done.includes(x.id)?" · ✓ مكتمل":""}</small><br><button data-lesson="${x.id}">افتح الدرس ←</button></article>`).join(""):'<p>لا توجد نتائج مطابقة.</p>'}
document.getElementById("searchLesson").oninput=renderLessons;document.getElementById("unitFilter").onchange=renderLessons;
document.addEventListener("click",e=>{let b=e.target.closest("[data-lesson]");if(b)openLesson(b.dataset.lesson)});
function openLesson(id){let x=DB.lessons.find(a=>a.id===id);if(!x)return;document.getElementById("lessonBody").innerHTML=`<span class="tag">${DB.units[x.unit]} · ${x.time}</span><h2>${esc(x.title)}</h2><p>${esc(x.summary)}</p><h3>أهداف الدرس</h3><ul>${x.objectives.map(y=>`<li>${esc(y)}</li>`).join("")}</ul>${x.sections.map(s=>`<h3>${esc(s[0])}</h3><p>${esc(s[1])}</p>`).join("")}<h3>العلاقة الأساسية</h3><div class="equation">${esc(x.formula)}</div><h3>مثال تطبيقي</h3><p>${esc(x.example)}</p><div class="card"><b>خلاصة</b><p>${esc(x.summaryEnd)}</p></div><button class="primary" id="markLesson" data-mark="${x.id}">${state.done.includes(x.id)?"مكتمل ✓":"علّم الدرس كمكتمل +20 XP"}</button>`;document.getElementById("lessonModal").classList.add("open")}
document.getElementById("closeModal").onclick=()=>document.getElementById("lessonModal").classList.remove("open");
document.getElementById("lessonModal").onclick=e=>{if(e.target.id==="lessonModal")e.currentTarget.classList.remove("open")};
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.getElementById("lessonModal").classList.remove("open")});
document.addEventListener("click",e=>{let b=e.target.closest("[data-mark]");if(!b)return;let id=b.dataset.mark;if(!state.done.includes(id)){state.done.push(id);state.xp+=20;save();renderLessons();toast("أحسنت! أضيفت 20 نقطة خبرة.")}b.textContent="مكتمل ✓"});
function renderExercises(){let q=document.getElementById("exerciseSearch").value.toLowerCase().trim(),level=document.getElementById("exerciseLevel").value;let a=DB.exercises.filter(x=>(level==="all"||x.level===level)&&(!q||(x.title+x.prompt+DB.units[x.unit]).toLowerCase().includes(q)));document.getElementById("exerciseGrid").innerHTML=a.map(x=>`<article class="card exercise-card"><span class="tag">${DB.units[x.unit]} · ${x.level==="easy"?"أساسي":x.level==="medium"?"متوسط":"تحدّي"}</span><h3>${esc(x.title)}</h3><p>${esc(x.prompt)}</p><button data-solution="${x.id}">كشف التلميح والحل</button><div class="solution" id="sol${x.id}"><p><b>تلميح:</b> ${esc(x.tip)}</p><ol>${x.steps.map(s=>`<li>${esc(s)}</li>`).join("")}</ol><div class="equation">${esc(x.answer)}</div></div></article>`).join("")||"<p>لا توجد تمارين.</p>"}
document.getElementById("exerciseSearch").oninput=renderExercises;document.getElementById("exerciseLevel").onchange=renderExercises;
document.addEventListener("click",e=>{let b=e.target.closest("[data-solution]");if(!b)return;let s=document.getElementById("sol"+b.dataset.solution);s.classList.toggle("open");b.textContent=s.classList.contains("open")?"إخفاء الحل":"كشف التلميح والحل"});
function startQuiz(){quiz={i:0,order:DB.questions.map((_,i)=>i),score:0,answered:false,finished:false};for(let i=quiz.order.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[quiz.order[i],quiz.order[j]]=[quiz.order[j],quiz.order[i]]}renderQuestion()}
function renderQuestion(){let q=DB.questions[quiz.order[quiz.i]];quiz.answered=false;document.getElementById("quizCategory").textContent=q.cat;document.getElementById("quizCounter").textContent=`السؤال ${quiz.i+1} من ${quiz.order.length}`;document.getElementById("quizBar").style.width=(quiz.i/quiz.order.length*100)+"%";document.getElementById("quizFeedback").textContent="";document.getElementById("quizFeedback").className="feedback";document.getElementById("nextQuestion").disabled=true;document.getElementById("nextQuestion").textContent=quiz.i===quiz.order.length-1?"عرض النتيجة":"السؤال التالي ←";document.getElementById("quizContent").innerHTML=`<h2 class="question">${esc(q.q)}</h2>${q.opts.map((o,i)=>`<button class="option" data-answer="${i}"><span class="letter">${["أ","ب","ج","د"][i]}</span>${esc(o)}</button>`).join("")}`}
document.addEventListener("click",e=>{let b=e.target.closest("[data-answer]");if(!b||quiz.answered||quiz.finished)return;answerQuestion(+b.dataset.answer)});
function answerQuestion(n){quiz.answered=true;let q=DB.questions[quiz.order[quiz.i]],good=n===q.a;document.querySelectorAll("[data-answer]").forEach((b,i)=>{b.disabled=true;if(i===q.a)b.classList.add("correct");if(i===n&&!good)b.classList.add("wrong")});state.answers++;if(good){quiz.score++;state.correct++;state.xp+=10}save();let f=document.getElementById("quizFeedback");f.className="feedback "+(good?"good":"bad");f.textContent=(good?"إجابة صحيحة! +10 XP. ":"الإجابة الصحيحة باللون الأخضر. ")+q.why;document.getElementById("nextQuestion").disabled=false;document.getElementById("quizBar").style.width=((quiz.i+1)/quiz.order.length*100)+"%"}
document.getElementById("nextQuestion").onclick=()=>{if(!quiz.answered||quiz.finished)return;if(quiz.i<quiz.order.length-1){quiz.i++;renderQuestion()}else{quiz.finished=true;let p=Math.round(quiz.score/quiz.order.length*100);document.getElementById("quizContent").innerHTML=`<div class="card"><div class="big">${p}%</div><h2>أكملت الاختبار!</h2><p>إجابات صحيحة: ${quiz.score} من ${quiz.order.length}.</p><p>${p>=80?"ممتاز! واصل المراجعة.":"راجع الدروس ثم حاول مجددًا."}</p></div>`;document.getElementById("quizFeedback").textContent="يمكنك إعادة الاختبار بتسلسل أسئلة مختلف.";document.getElementById("nextQuestion").disabled=true;document.getElementById("quizBar").style.width="100%"}};
document.getElementById("restartQuiz").onclick=startQuiz;
function renderFormulas(){let q=document.getElementById("formulaSearch").value.toLowerCase().trim(),a=DB.formulas.filter(x=>(x.title+x.eq+x.meaning+x.units+x.cat).toLowerCase().includes(q));document.getElementById("formulaGrid").innerHTML=a.map(x=>`<article class="card formula-card"><span class="tag">${x.cat}</span><h3>${esc(x.title)}</h3><div class="equation">${esc(x.eq)}</div><p>${esc(x.meaning)}</p><small>${esc(x.units)}</small></article>`).join("")||"<p>لا توجد قوانين مطابقة.</p>"}
document.getElementById("formulaSearch").oninput=renderFormulas;
function renderProgress(){let done=DB.lessons.filter(x=>state.done.includes(x.id)).length,p=Math.round(done/DB.lessons.length*100);document.getElementById("percent").textContent=p+"%";document.getElementById("progressBar").style.width=p+"%";document.getElementById("progressText").textContent=`أكملت ${done} من ${DB.lessons.length} دروس.`;document.getElementById("totalXP").textContent=state.xp+" XP";document.getElementById("progressList").innerHTML=DB.lessons.map(x=>`<div class="progress-row"><b>${esc(x.title)}</b><div class="bar"><span style="width:${state.done.includes(x.id)?100:0}%"></span></div><small>${state.done.includes(x.id)?"مكتمل ✓":"قيد التعلّم"}</small></div>`).join("");let badges=[["🌱","البداية","أكمل درسًا",done>=1],["📚","قارئ نشيط","أكمل 3 دروس",done>=3],["🧠","مستكشف","أكمل 5 دروس",done>=5],["🎯","مجيب","أجب عن 5 أسئلة",state.answers>=5],["⭐","خبير ناشئ","اجمع 100 XP",state.xp>=100],["🏆","متفوّق","أكمل كل الدروس",done===DB.lessons.length]];document.getElementById("badges").innerHTML=badges.map(x=>`<div class="badge ${x[3]?"earned":""}"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join("")}
document.getElementById("resetProgress").onclick=()=>{if(confirm("هل تريد مسح التقدم المحفوظ؟")){let theme=state.theme;state={...fresh(),theme};save();renderLessons();renderExercises();toast("تمت إعادة ضبط التقدم.")}};
function labInputs(){let config={ohm:{title:"دارة أومية بسيطة",intro:"غيّر التوتر والمقاومة لملاحظة أثرهما في شدة التيار.",eq:"I = U / R",inputs:[["voltage","التوتر U",1,12,6,1,"V"],["resistance","المقاومة R",2,30,10,1,"Ω"]]},series:{title:"دارة على التسلسل",intro:"قارن المقاومة الكلية وشدة التيار في دارة تسلسلية.",eq:"Rₜ = R₁ + R₂",inputs:[["voltage","التوتر U",1,12,9,1,"V"],["resistance","المقاومة R₁",2,20,4,1,"Ω"],["resistance2","المقاومة R₂",2,20,5,1,"Ω"]]},power:{title:"حساب الاستطاعة",intro:"غيّر التوتر وشدة التيار لحساب الاستطاعة.",eq:"P = U × I",inputs:[["voltage","التوتر U",1,24,12,1,"V"],["current","التيار I",1,5,2,.5,"A"]]}}[labMode];document.getElementById("labTitle").textContent=config.title;document.getElementById("labIntro").textContent=config.intro;document.getElementById("labEquation").textContent=config.eq;document.getElementById("labInputs").innerHTML=config.inputs.map(x=>`<div class="lab-input"><label for="${x[0]}">${x[1]} <output id="${x[0]}Out">${x[4]} ${x[6]}</output></label><input type="range" id="${x[0]}" min="${x[2]}" max="${x[3]}" value="${x[4]}" step="${x[5]}"></div>`).join("");config.inputs.forEach(x=>document.getElementById(x[0]).oninput=updateLab);updateLab()}
function value(id,def=0){let e=document.getElementById(id);return e?+e.value:def}
function updateLab(){let u=value("voltage",6),r=value("resistance",10),r2=value("resistance2",5),current=value("current",2);[["voltage","V"],["resistance","Ω"],["resistance2","Ω"],["current","A"]].forEach(x=>{let e=document.getElementById(x[0]+"Out");if(e)e.textContent=value(x[0])+" "+x[1]});let readings,insight;if(labMode==="ohm"){let i=u/r;readings=[["شدة التيار",i.toFixed(2),"A"],["التوتر",u,"V"],["المقاومة",r,"Ω"]];insight=`I=${u}/${r}=${i.toFixed(2)} A. عند ثبات المقاومة، زيادة التوتر تزيد التيار.`}else if(labMode==="series"){let total=r+r2,i=u/total;readings=[["المقاومة الكلية",total,"Ω"],["شدة التيار",i.toFixed(2),"A"],["التوتر",u,"V"]];insight=`المقاومة الكلية ${r}+${r2}=${total} Ω. التيار نفسه يمر في عناصر التسلسل المثالية.`}else{let p=u*current;readings=[["الاستطاعة",p.toFixed(1),"W"],["التوتر",u,"V"],["التيار",current,"A"]];insight=`P=${u}×${current}=${p.toFixed(1)} W.`}document.getElementById("readings").innerHTML=readings.map(x=>`<div class="reading"><small>${x[0]}</small><b>${x[1]} ${x[2]}</b></div>`).join("");document.getElementById("insightText").textContent=insight;document.getElementById("circuit").innerHTML=circuitSVG()}
function circuitSVG(){let dual=labMode==="series",label=labMode==="power"?"P=U·I":dual?"R₁ / R₂":"R";return `<svg viewBox="0 0 400 210" role="img" aria-label="دارة كهربائية افتراضية"><path d="M65 75 H155 M${dual?300:260} 75 H340 V150 H65 V75" fill="none" stroke="#63e4ee" stroke-width="3"/><rect x="155" y="60" width="105" height="30" rx="5" fill="#173b50" stroke="#63e4ee" stroke-width="2"/><text x="207" y="80" text-anchor="middle" fill="#eff7ff" font-size="12">${label}</text>${dual?'<rect x="260" y="60" width="40" height="30" rx="4" fill="#173b50" stroke="#63e4ee" stroke-width="2"/>':''}<path d="M65 95 V130 M52 103 H78 M57 122 H73" stroke="#ffc477" stroke-width="3"/><text x="91" y="117" fill="#ffc477" font-size="13">U</text><path d="M265 150 H310 l-10 -6 v12 z" fill="#64e7ae"/><text x="282" y="138" fill="#64e7ae" font-size="12">I</text><text x="200" y="185" text-anchor="middle" fill="#9cb2c7" font-size="12">محاكاة تعليمية وليست دارة حقيقية</text></svg>`}
document.querySelectorAll("[data-lab]").forEach(b=>b.onclick=()=>{labMode=b.dataset.lab;document.querySelectorAll("[data-lab]").forEach(x=>x.classList.toggle("selected",x===b));labInputs()});document.getElementById("resetLab").onclick=labInputs;
document.getElementById("year").textContent=new Date().getFullYear();document.body.classList.toggle("light",state.theme==="light");document.getElementById("theme").textContent=state.theme==="light"?"☾":"☼";
updateStats();renderLessons();renderExercises();renderFormulas();renderProgress();labInputs();startQuiz();
if(location.hash){let id=location.hash.slice(1);if(document.getElementById(id))go(id)}
